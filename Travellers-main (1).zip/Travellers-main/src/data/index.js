export const footerLinks = [

    {
        Heading: 'Company',
        links: [
            {
                name: "Careere",
                path: "/careere"
            },
            {
                name: "About Us",
                path: "/aboutus"
            },
            {
                name: "Blog",
                path: "/Blog"
            },
            {
                name: "Press Infor",
                path: "/Blog"
            },
            {
                name: "Features",
                path: "/Blog"
            },
            {
                name: "Successes",
                path: "/Blog"
            },

        ]
    },
    {
        Heading: 'Travellers',
        links: [
            {
                name: "Why Travellers",
                path: "/careere"
            },
            {
                name: "Enterprise",
                path: "/aboutus"
            },
            {
                name: "Customer Stories",
                path: "/Blog"
            },
            {
                name: "Pricing",
                path: "/Blog"
            },
            {
                name: "Secutity",
                path: "/Blog"
            },

        ]
    },
    {
        Heading: 'Resources',
        links: [
            {
                name: "Download",
                path: "/careere"
            },
            {
                name: "Help Center",
                path: "/aboutus"
            },
            {
                name: "Guides",
                path: "/Blog"
            },
            {
                name: "Events",
                path: "/Blog"
            },
            {
                name: "Developers",
                path: "/Blog"
            },
            {
                name: "App Directory",
                path: "/Blog"
            },
            {
                name: "Partners",
                path: "/Blog"
            },

        ]
    },
    {
        Heading: 'Extras',
        links: [
            {
                name: "Podcast",
                path: "/careere"
            },
            {
                name: "Travellers Shop",
                path: "/aboutus"
            },
            {
                name: "Travellers at Work",
                path: "/Blog"
            },
            {
                name: "Travellers Fund",
                path: "/Blog"
            },
            {
                name: "Integrations",
                path: "/Blog"
            },

        ]
    },
]