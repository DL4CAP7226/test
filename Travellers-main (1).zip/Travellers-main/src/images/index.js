import appStoreimg from './store.png'
import user from './user.png'
import secionSix from './secion6.png'



export {
    appStoreimg,user,secionSix
}