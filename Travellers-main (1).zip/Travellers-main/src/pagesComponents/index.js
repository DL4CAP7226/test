export {default as SectionOne} from './homePage/SectionOne';
export {default as SectionTwo} from './homePage/SectionTwo';
export {default as SectionThree} from './homePage/SectionThree';
export {default as SectionFour} from './homePage/SectionFour';
export {default as SectionFive} from './homePage/SectionFive';